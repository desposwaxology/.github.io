<?php
session_start(); // Start a new  session.
// Check if the user is logged in.
if (isset($_SESSION['username'])) {
   // If the user is logged in, display logout button.
  echo '<a href="logout.php">Logout</a>';
  // If the user is logged in as admin, display the "My Bookings" button.
  if (isset($_SESSION['admin']) && $_SESSION['admin'] == true) {
    echo '<li><a href="my-bookings.html">My Bookings</a></li>';
  }
} else {
  // If the user is not logged in, display login button
  echo '<a href="login.html">Login</a>';
}

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
			<meta charset="UTF-8">
			<link rel="stylesheet" href="styles/styles.css">
			<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	</head>
	<body>
	<div id="pagewrapper">
		
	    <header>
		<div class="slideshow"> 
		<img src="media/slide1.jpeg" alt="Slide 1">
		<img src="media/slide3.jpeg" alt="Slide 2">
		<img src="media/slide2.jpeg" alt="Slide 3">
		</div>

			<h1>Despo's Waxology</h1>
			<h2>Discover The Beauty Within</h2>
		</header>
	    <nav id="primarynav">
			<ul>
			    <li><a href="#" class="current">Home</a></li>
				<li><a href="services.html">Services</a></li>
				<li><a href="Form.html" >Book an Appointment</a></li>
				<?php
				 // If the user is an admin display my bookings
				if (isset($_SESSION['admin']) && $_SESSION['admin'] == true) {
					echo '<li><a href="my-bookings.html" >My Bookings</a></li>';
				}
				?>
			</ul>
		</nav>
		<section>
			
			<p>
			Welcome to Despo’s beauty salon, where beauty is not only about how you look but also about how you feel. Despo’s is a place where you can come to unwind, relax, and indulge in a variety of beauty treatments and services. Offering a wide range of services, including waxing, manicures, pedicures, facials, massages, and more.

			Despo is a skilled professional dedicated to providing you with the highest quality services, using the latest techniques and products to ensure that you leave feeling refreshed, rejuvenated, and beautiful.

			Whether you are looking for a quick waxing or a full day of pampering, Despo’s has everything you need to look and feel your best. So why wait? Book your appointment today and discover your beauty inside and out.
			</p>
		</section>
		<script>
		// Declare variable and set ro 0
		var slideIndex = 0; 
		showSlides();
		// Define showSlides() function
		function showSlides() {
			// Select the img elements and store them them in the slides variable
			var slides = document.getElementsByClassName("slideshow")[0].getElementsByTagName("img");
			// Loop through slides and remove the active class
			for (var i = 0; i < slides.length; i++) {
				slides[i].classList.remove("active");
			}
			// Increment slideIndex
			slideIndex++;
			//Check if slideIndex greater than img elements in the slides array and set back to 1 if it is
			if (slideIndex > slides.length) {
				slideIndex = 1;
			}
			// Add the active class to img and call the function in 5 seconds.
			slides[slideIndex-1].classList.add("active");
			setTimeout(showSlides, 5000); 
		}
		</script>
		
		<footer>
		<div class="container">
		<p>&copy; 2023 Despo's Waxology. All rights reserved. Follow us on <a href="https://www.instagram.com/despo_waxology/">Instagram</a>.</p>
		</div>
		</footer>
	</body>
</html>
