<?php
$filepath = realpath("users.txt");
// Check if the form has been submitted
if (isset($_POST['submit'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $file = fopen($filepath, "a");
  fwrite($file, $username . "," . $password . "\n");
  fclose($file);
  echo "User created successfully!";
}
// Check if the form has been submitted
if (isset($_POST['login'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $file = fopen($filepath, "r");
  // Loop through each line in the file
  while (!feof($file)) {
    // Get the line from the file
    $line = fgets($file);
    // Split the line into an array using the comma as a delimiter
    $user = explode(",", $line);
    if ($username == trim($user[0]) && $password == trim($user[1])) {
      // Check if the username and password match
      if ($username == "asarafopoulou@gmail.com" && $password == "paokpaok1926") {
        // Start the session and store the username in the session variable as admin
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['admin'] = true;
      } else {
        // Start the session and store the username in the session variable
        session_start();
        $_SESSION['username'] = $username;
      }
      // Redirect the user to the index page
        header("Location: index.php");
        exit();
    }
  }
  echo "Invalid username or password!";
  fclose($file);
}
// Check if the user is already logged in
session_start();
if (isset($_SESSION['username'])) {
  echo "Logged in as " . $_SESSION['username'];
  if (isset($_SESSION['admin'])) {
    echo " (Admin)";
  }
  echo " | <a href='logout.php'>Log out</a>";
} else {
  // Display the login form
  echo "<form method='post'>";
  echo "Username: <input type='text' name='username'><br>";
  echo "Password: <input type='password' name='password'><br>";
  echo "<input type='submit' name='login' value='login'>";
  echo "</form>";
}
?>