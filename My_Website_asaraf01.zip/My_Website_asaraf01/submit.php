<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form fields and remove whitespace
    $name = strip_tags(trim($_POST["name"]));
    $name = str_replace(array("\r","\n"),array(" "," "),$name);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST["phone"]);
    $datetime = trim($_POST["datetime"]);
   
    $service = trim($_POST["service"]);

    // Check that data was submitted to the mailer
    if ( empty($name) || empty($phone) || empty($datetime) || empty($service) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo "Oops! There was a problem with your submission. Please complete the form and try again.";
        exit;
    }

    // Check if the appointment slot is available
    if (!checkAvailability($datetime)) {
        // Slot is not available, inform user and ask them to choose another slot
        http_response_code(400);
        echo "Oops! The chosen date and time slot is not available. Please choose another slot.";
        exit;
    }

    // Set the recipient email address
    $recipient = "asarafopoulou@gmail.com";

    // Set the email subject
    $subject = "New Appointment Booking from $name";

    // Build the email content
    $email_content = "Name: $name\n";
    $email_content .= "Email: $email\n";
    $email_content .= "Phone: $phone\n";
    $email_content .= "Date: $datetime\n";
   
    $email_content .= "Service: $service\n";

    // Build the email headers
    $email_headers = "From: $name <$email>";

    // Send the email
    if (mail($recipient, $subject, $email_content, $email_headers)) {
        http_response_code(200);
        echo "Thank You! Your booking has been sent.";
        // Slot is available, book appointment and add to the CSV file
        $appointment = array($name, $email, $phone, $datetime, $service);
        addToAppointments($appointment);
    } else {
        http_response_code(500);
        echo "Oops! Something went wrong and we couldn't book your appointment.";
        exit;
    }

} else {
    http_response_code(403);
    echo "Oops! There was a problem with your submission. Please try again.";
}
// Check datetime input 
function checkAvailability($datetime) {
    $file_path = realpath('booked_appointments.csv');
	// If file booked_appointments.csv exists open and read, function return  true
    if (file_exists($file_path)) {
        $file = fopen($file_path, 'r');
        if ($file !== false) {
			// For each line in the file check if date and time match the input date and time string. If it matches function return false
            while (($line = fgetcsv($file)) !== false) {
                if (count($line) >= 4 && $line[3] === $datetime) {
                    fclose($file);
                    return false;
                }
            }
            fclose($file);
        } else {
            // Handle error opening file
            return false;
        }
    }
    return true;
}

function addToAppointments($appointment) {
$file_path = realpath('booked_appointments.csv');
if (!file_exists($file_path)) {
// Create the directory if it doesn't exist
$dir = dirname($file_path);
if (!file_exists($dir)) {
mkdir($dir, 0755, true);
}
}
// Append the appointment to the CSV file
$file = fopen($file_path, 'a');
if ($file !== false) {
fputcsv($file, $appointment);
fclose($file);
}
}